package com.example.android.navigation

import androidx.databinding.DataBindingUtil
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import com.example.android.navigation.databinding.FragmentGameBinding

class GameFragment : Fragment() {
    data class Question(
            val text: String,
            val answers: List<String>)


    private val questions: MutableList<Question> = mutableListOf(
            Question(text = "Apa sebutan Kampus UPN Veteran Jawa Timur?",
                    answers = listOf("Kampus Bela Negara", "Kampus Biru", "Kampus Perjuangan", "Kampus Pahlawan Reformasi")),
            Question(text = "Ada berapa jumlah keseluruhan fakultas di UPN Veteran Jawa Timur?",
                    answers = listOf("5", "7", "8", "4")),
            Question(text = "Manakah dari Kota berikut yang tidak terdapat Kampus UPN Veteran?",
                    answers = listOf("Surabaya", "Jakarta", "Bandung", "Yogyakarta")),
            Question(text = "Kapan UPN Veteran Jawa Timur didirikan?",
                    answers = listOf("6 Agustus 1959", "6 Juli 1959", "5 Agustus 1959", "5 Juli 1959")),
            Question(text = "Sikap dan perilaku warga negara yang dijiwai oleh kecintaan terhadap NKRI yang berdasarkan Pancasila dan UUD 1945 disebut?",
                    answers = listOf("Bela Negara", "Bela Tanah Air", "Sumpah Pemuda", "Kemerdekaan")),
            Question(text = "Ada berapakah jumlah keseluruhan Unit Kegiatan Mahasiswa di UPN Veteran Jawa Timur?",
                    answers = listOf("37", "30", "35", "40")),
            Question(text = "Unit Pelaksana Teknis di UPN Veteran Jawa Timur yang berkaitan dengan segala layanan IT disebut?",
                    answers = listOf("UPT-TIK", "UPT-Pengembangan Karir dan KWU", "UPT-Perpustakaan", "UPT-Pusat Bahasa")),
            Question(text = "Salah satu fasilitas di UPN Veteran Jawa Timur dimana mahasiswa putri dapat tinggal sementara disana selama beberapa semester disebut?",
                    answers = listOf("Rusunawa Putri", "Masjid Istiqomah", "Kolam Renang", "Gedung Techno Park")),
            Question(text = "Salah satu prodi di UPN Veteran Jawa Timur adalah prodi Sistem Informasi. Sejak tahun berapakah prodi Sistem Informasi didirikan?",
                    answers = listOf("2003", "2007", "2005", "2010")),
            Question(text = "Fakultas di UPN Veteran Jawa Timur yang merupakan fakultas tertua dan memiliki jumlah mahasiswa paling banyak adalah?",
                    answers = listOf("FEB", "FIK", "FAD", "FH"))
    )

    lateinit var currentQuestion: Question
    lateinit var answers: MutableList<String>
    private var questionIndex = 0
    private val numQuestions = Math.min((questions.size + 1) / 2, 3)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {


        val binding = DataBindingUtil.inflate<FragmentGameBinding>(
                inflater, R.layout.fragment_game, container, false)


        randomizeQuestions()


        binding.game = this


        binding.submitButton.setOnClickListener { view: View ->
            val checkedId = binding.questionRadioGroup.checkedRadioButtonId
            // Do nothing if nothing is checked (id == -1)
            if (-1 != checkedId) {
                var answerIndex = 0
                when (checkedId) {
                    R.id.secondAnswerRadioButton -> answerIndex = 1
                    R.id.thirdAnswerRadioButton -> answerIndex = 2
                    R.id.fourthAnswerRadioButton -> answerIndex = 3
                }

                if (answers[answerIndex] == currentQuestion.answers[0]) {
                    questionIndex++
                    // Advance to the next question
                    if (questionIndex < numQuestions) {
                        currentQuestion = questions[questionIndex]
                        setQuestion()
                        binding.invalidateAll()
                    } else {
                        // We've won!  Navigate to the gameWonFragment.
                        view.findNavController().navigate(GameFragmentDirections.actionGameFragmentToGameWonFragment(numQuestions,questionIndex))
                    }
                } else {
                    // Game over! A wrong answer sends us to the gameOverFragment.
                    view.findNavController().navigate(GameFragmentDirections.actionGameFragmentToGameOverFragment())
                }
            }
        }
        return binding.root
    }


    private fun randomizeQuestions() {
        questions.shuffle()
        questionIndex = 0
        setQuestion()
    }


    private fun setQuestion() {
        currentQuestion = questions[questionIndex]
        // randomize the answers into a copy of the array
        answers = currentQuestion.answers.toMutableList()
        // and shuffle them
        answers.shuffle()
        (activity as AppCompatActivity).supportActionBar?.title = getString(R.string.title_android_trivia_question, questionIndex + 1, numQuestions)
    }
}
